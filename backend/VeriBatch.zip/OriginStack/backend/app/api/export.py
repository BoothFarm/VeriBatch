"""
Export API endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from typing import Annotated
from datetime import datetime

from app.db.database import get_db
from app.services import export_service
from app.models import database as db_models # Import db_models
from app.dependencies import get_current_active_user_and_owned_actor # Add this import

router = APIRouter(prefix="/actors/{actor_id}/export", tags=["export"])


@router.get("/summary")
def get_export_summary(
    actor: Annotated[db_models.Actor, Depends(get_current_active_user_and_owned_actor)],
    db: Annotated[Session, Depends(get_db)]
):
    """
    Get summary of what would be exported for this actor (Protected)
    
    Returns count of each entity type
    """
    summary = export_service.get_export_summary(db, actor.id) # Use actor.id from dependency
    
    if not summary:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Actor not found") # Should not happen due to dependency
    
    return summary


@router.get("/ooj-archive")
def export_ooj_archive(
    actor: Annotated[db_models.Actor, Depends(get_current_active_user_and_owned_actor)],
    db: Annotated[Session, Depends(get_db)]
):
    """
    Export all OOJ entities as a ZIP archive (Protected)
    
    Returns a downloadable ZIP file containing:
    - actor.json
    - items/*.json
    - batches/*.json
    - events/*.json
    - processes/*.json
    - locations/*.json
    - README.txt
    """
    # Check if actor exists
    summary = export_service.get_export_summary(db, actor.id) # Use actor.id from dependency
    if not summary:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Actor not found") # Should not happen due to dependency
    
    # Generate ZIP archive
    zip_buffer = export_service.export_actor_ooj_archive(db, actor.id) # Use actor.id from dependency
    
    # Return as downloadable file
    timestamp = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    filename = f"ooj-export-{actor.id}-{timestamp}.zip" # Use actor.id from dependency
    
    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={
            "Content-Disposition": f"attachment; filename={filename}"
        }
    )
