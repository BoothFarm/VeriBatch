"""
OOJ Schema definitions
Placeholder for Open Origin JSON schema validation
"""

# OOJ v0.5 schema information
OOJ_VERSION = "0.5"
OOJ_SCHEMA_URL = "open-origin-json/0.5"
